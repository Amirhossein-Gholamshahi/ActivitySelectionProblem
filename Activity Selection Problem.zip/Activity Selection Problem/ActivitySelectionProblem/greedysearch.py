# solving activity selection problem using greedy search
# a 2D array  represents the activities
# for every activity like ai , index of each element is the index of activity(i)
# and first parameter is starting time (si) and second parameter is ending time (fi) )
def select_action(activities):
    sorted_activities = sorted(activities, key=lambda x: x[1])
    solution = []
    solution_sequence = ""
    solution.append(sorted_activities[1])
    for i in range(2,len(sorted_activities)):
            if sorted_activities[i][0] >= solution[-1][1]:
                solution.append(sorted_activities[i])
    for j in range(0,len(solution)):
        k = activities.index(solution[j])
        solution_sequence = solution_sequence + "a" + str(k) + "-->"
    return solution_sequence.strip("-->")
# now we will use our function to solve this activity selection problem represented below
activities1 =[[0, 0], [1, 4], [2, 8], [3, 5], [12, 14], [1, 3], [5, 9], [10, 12], [4, 7], [3, 10]]  # fill the first element with [0,0] because activities start from index 1
print("Solution Sequence is : "+select_action(activities1))

