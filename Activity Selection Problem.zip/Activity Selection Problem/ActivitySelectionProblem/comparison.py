# first we generate a set of random activities and then run both algorithms on them
import random
import time

import exhaustivesearch
import greedysearch
from itertools import combinations,chain
import sys
def select_action(activities):
    sorted_activities = sorted(activities, key=lambda x: x[1])
    solution = []
    solution_sequence = ""
    solution.append(sorted_activities[1])
    for i in range(2,len(sorted_activities)):
            if sorted_activities[i][0] >= solution[-1][1]:
                solution.append(sorted_activities[i])
    for j in range(0,len(solution)):
        k = activities.index(solution[j])
        solution_sequence = solution_sequence + "a" + str(k) + "-->"
    return solution_sequence.strip("-->")
def powerset(iterable):  #function to make the powerset of any given set
    "powerset([1,2,3]) → () (1,) (2,) (3,) (1,2) (1,3) (2,3) (1,2,3)"
    s = list(iterable)
    return chain.from_iterable(combinations(s, r) for r in range(len(s)+1))
def compatible(lst): # retrns number of compatible items in an array
    num_of_compatible_elements = 0
    is_compatible = False
    sort = sorted(lst, key=lambda x: x[1])
    if len(sort) == 1:  # every subset with an only element is compatible with itself
        is_compatible = True
        num_of_compatible_elements = num_of_compatible_elements + 1
    for i in range(len(sort)):
        for j in range(i+1,len(sort)):
          if sort[i][1]<=sort[j][0]:
              is_compatible=True
              num_of_compatible_elements = num_of_compatible_elements + 1
          else:
              is_compatible = False
    return num_of_compatible_elements
def fact(num): #factoriel function
    factor = 1
    if num == -1:
        return 0.5
    if num == 0:
        return 1
    if num == 1:
        return 1
    else:
        for i in range(1,num+1):
            factor = factor *i
        return factor
def select_action_all(activities):
    powerset_of_activities = []
    list1 = []
    solution = []
    for x in powerset(activities):
        powerset_of_activities.append(list(x))
    powerset_of_activities.remove([]) # removing the empty subset because its not useful (doing nothing is never gonna be the best case)
    for i in powerset_of_activities:
        j = fact(len(i)) / (2 * fact(len(i) - 2))
        if compatible(i) == j or len(i)==1:
            list1.append(i)
    #max_length = (len(max(list1, key=len)))
    for j in list1:
        sorted_j = sorted(j, key=lambda x: x[1])
        solution.append(sorted_j)
    lst_of_solution_seqs = []
    for m in solution:
        solution_sequence= ""
        for n in m:
            k = activities.index(n)+1
            solution_sequence = solution_sequence + "a" + str(k) + "-->"
        solution_sequence = solution_sequence.strip("-->")
        lst_of_solution_seqs.append(solution_sequence)
    return lst_of_solution_seqs
def select_action_optimal(activities): # optimal solution is the one that contains doing more activites in less time
    powerset_of_activities = []
    list1 = []
    solution = []
    for x in powerset(activities):
        powerset_of_activities.append(list(x))
    powerset_of_activities.remove([])  # removing the empty subset because its not useful
    for i in powerset_of_activities:
        j = fact(len(i)) / (2 * fact(len(i) - 2))
        if compatible(i) == j or len(i) == 1:
            list1.append(i)
    max_length = (len(max(list1, key=len)))
    for j in list1:
        if len(j)==max_length:
            sorted_j = sorted(j, key=lambda x: x[1])
            solution.append(sorted_j)
    lst_of_solution_seqs = []
    for m in solution:
        solution_sequence = ""
        for n in m:
            k = activities.index(n) + 1
            solution_sequence = solution_sequence + "a" + str(k) + "-->"
        solution_sequence = solution_sequence.strip("-->")
        lst_of_solution_seqs.append(solution_sequence)
    l1 = []
    if len(lst_of_solution_seqs)>=1:
        for i in lst_of_solution_seqs:
            k = int(i[-1])
            end_time = activities[k-1]
            l1.append(end_time)
        min_end = min(l1)
    opt_sol = lst_of_solution_seqs[l1.index(min_end)]
    lst_of_solution_seqs = opt_sol
    return lst_of_solution_seqs


#generating random 2D array
def generate_random_activities(n):
    lst = []
    for i in range(n):
        j = random.randint(0, 9)
        k = random.randint(j + 1, 10)
        m = [j,k]
        lst.append(m)
    return lst
k = generate_random_activities(10) #removing duplicates from the list
res = []
for i in k:
    if i not in res:
        res.append(i)
s1 = time.time()
print(select_action(res))
f1 = time.time()
print(f1-s1)

s2 = time.time()
print(select_action_optimal(res))
f2 = time.time()
print(f2-s2)





